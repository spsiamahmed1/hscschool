package com.example.hscresult;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        findViewById(R.id.cardResult).setOnClickListener(v ->
                startActivity(new Intent(this, ResultWebActivity.class)));
        findViewById(R.id.cardGpa).setOnClickListener(v ->
                startActivity(new Intent(this, GpaActivity.class)));
        findViewById(R.id.cardSaved).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle(R.string.saved_results)
                        .setMessage(R.string.no_saved)
                        .setPositiveButton("OK", null)
                        .show());
        findViewById(R.id.cardNotice).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle(R.string.notice)
                        .setMessage("HSC Result 2026 প্রকাশ নিয়ে শীঘ্রই আপডেট।")
                        .setPositiveButton("OK", null)
                        .show());
        findViewById(R.id.cardSettings).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
    }
}
