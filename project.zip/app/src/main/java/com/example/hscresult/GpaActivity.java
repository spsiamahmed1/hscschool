package com.example.hscresult;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class GpaActivity extends AppCompatActivity {
    private LinearLayout container;
    private TextView tvResult;
    private final List<Spinner> spinners = new ArrayList<>();
    private static final String[] GRADES = {"A+", "A", "A-", "B", "C", "D", "F"};
    private static final double[] POINTS = {5.00, 4.00, 3.50, 3.00, 2.00, 1.00, 0.00};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_gpa);
        container = findViewById(R.id.container);
        tvResult = findViewById(R.id.tvResult);
        Button btnCalc = findViewById(R.id.btnCalc);

        for (int i = 0; i < 6; i++) addRow();
        btnCalc.setOnClickListener(v -> calculate());
    }

    private void addRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(8, 8, 8, 8);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView no = new TextView(this);
        no.setText(String.valueOf(spinners.size() + 1) + ". ");
        no.setTextSize(14f);
        no.setPadding(0, 0, 8, 0);
        no.setWidth(60);

        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, GRADES);
        sp.setAdapter(ad);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        sp.setLayoutParams(lp);

        row.addView(no);
        row.addView(sp);
        spinners.add(sp);
        container.addView(row);
    }

    private void calculate() {
        double sum = 0;
        for (int i = 0; i < spinners.size(); i++) {
            double p = POINTS[spinners.get(i).getSelectedItemPosition()];
            if (i < 6 && p == 0) {
                tvResult.setText("F — Fail / অকৃতকার্য");
                return;
            }
            if (i < 6) sum += p;
        }
        double gpa = sum / 6.0;
        if (gpa > 5.0) gpa = 5.0;
        tvResult.setText(String.format("GPA: %.2f", gpa));
    }
}
