package com.example.hscresult;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import com.google.android.material.materialswitch.MaterialSwitch;

public class SettingsActivity extends AppCompatActivity {
    private static final String P = "settings";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);

        SharedPreferences sp = getSharedPreferences(P, MODE_PRIVATE);

        MaterialSwitch swDark = findViewById(R.id.swDark);
        swDark.setChecked(sp.getBoolean("dark", false));
        swDark.setOnCheckedChangeListener((btn, checked) -> {
            sp.edit().putBoolean("dark", checked).apply();
            AppCompatDelegate.setDefaultNightMode(checked
                    ? AppCompatDelegate.MODE_NIGHT_YES
                    : AppCompatDelegate.MODE_NIGHT_NO);
        });

        findViewById(R.id.cardPrivacy).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle(R.string.privacy)
                        .setMessage(R.string.privacy_body)
                        .setPositiveButton("OK", null)
                        .show());
    }
}
